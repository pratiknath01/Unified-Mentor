import React from 'react'

const Footer = () => {
  return (
    <footer>
        Designed And Developed By Deepak
    </footer>
  )
}

export default Footer
