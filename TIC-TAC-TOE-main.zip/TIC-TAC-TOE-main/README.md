# TIC-TAC-TOE

Implemented interactive tic-tac-toe game with clickable cells, win condition checks, reset button, and congratulatory messages using JavaScript. Demonstrates proficiency in logic implementation and user interface design.
